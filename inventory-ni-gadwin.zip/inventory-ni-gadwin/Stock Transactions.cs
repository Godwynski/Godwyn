﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inventory_ni_gadwin
{
    public partial class stocktransactions : Form
    {
        public stocktransactions()
        {
            InitializeComponent();
            LoadData();
            loadProducts();
        }

        private void UserGrid_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        void LoadData()
        {
            // Connection string for XAMPP
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";

            // SQL query to retrieve data with the product name
            string query = @"
        SELECT 
            t.TransactionID, 
            p.Name AS ProductName, 
            t.Quantity, 
            t.Date, 
            t.CustomerOrSupplier, 
            t.TransactionType 
        FROM transactions t
        INNER JOIN products p ON t.ProductID = p.ProductID";

            // Establish the connection
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    connection.Open();

                    // Create a MySqlDataAdapter to retrieve data
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(query, connection);

                    // Create a DataTable to hold the retrieved data
                    DataTable dataTable = new DataTable();

                    // Fill the DataTable with data from the query
                    dataAdapter.Fill(dataTable);

                    // Bind the data to the DataGridView
                    TransactionsGrid.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    // Handle exceptions (e.g., display an error message)
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            // Connection string for XAMPP
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";

            // Retrieve values from controls
            string selectedProduct = PurchaseSelectProduct.SelectedItem?.ToString();
            string quantityText = PurchaseQuantity.Text;
            int quantity;

            // Validate input
            if (string.IsNullOrWhiteSpace(selectedProduct) || string.IsNullOrWhiteSpace(quantityText) || !int.TryParse(quantityText, out quantity))
            {
                MessageBox.Show("Please select a product and enter a valid quantity.");
                return;
            }

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    connection.Open();

                    // Retrieve ProductID and SupplierID based on the selected product name
                    string productIdQuery = "SELECT ProductID, SupplierID FROM products WHERE Name = @ProductName";
                    int productId = -1;
                    int supplierId = -1;
                    string supplierName = "";

                    using (MySqlCommand cmd = new MySqlCommand(productIdQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@ProductName", selectedProduct);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                productId = reader.GetInt32("ProductID");
                                supplierId = reader.GetInt32("SupplierID");
                            }
                        }
                    }

                    if (productId == -1 || supplierId == -1)
                    {
                        MessageBox.Show("Product or supplier not found.");
                        return;
                    }

                    // Retrieve supplier name using SupplierID
                    string supplierNameQuery = "SELECT Name FROM suppliers WHERE SupplierID = @SupplierID";
                    using (MySqlCommand cmd = new MySqlCommand(supplierNameQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@SupplierID", supplierId);
                        supplierName = cmd.ExecuteScalar()?.ToString();
                    }

                    if (string.IsNullOrEmpty(supplierName))
                    {
                        MessageBox.Show("Supplier not found.");
                        return;
                    }

                    // Insert into transactions table (TransactionID is auto-incremented)
                    string insertTransactionQuery = @"
            INSERT INTO transactions 
            (ProductID, Quantity, Date, CustomerOrSupplier, TransactionType) 
            VALUES (@ProductID, @Quantity, @Date, @CustomerOrSupplier, @TransactionType)";

                    using (MySqlCommand cmd = new MySqlCommand(insertTransactionQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@ProductID", productId);
                        cmd.Parameters.AddWithValue("@Quantity", quantity);
                        cmd.Parameters.AddWithValue("@Date", DateTime.Now);
                        cmd.Parameters.AddWithValue("@CustomerOrSupplier", supplierName);
                        cmd.Parameters.AddWithValue("@TransactionType", "Purchase");

                        cmd.ExecuteNonQuery();
                    }
                    // Update StockQuantity in the products table
                    string updateStockQuery = "UPDATE products SET StockQuantity = StockQuantity + @Quantity WHERE ProductID = @ProductID";

                    using (MySqlCommand cmd = new MySqlCommand(updateStockQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@Quantity", quantity);
                        cmd.Parameters.AddWithValue("@ProductID", productId);
                        cmd.ExecuteNonQuery();
                    }

                    // Clear inputs and show success message
                    PurchaseSelectProduct.SelectedIndex = -1;
                    PurchaseQuantity.Text = "";
                    MessageBox.Show("Order successfully added to transactions.");

                    // Reload data in the grid or interface
                    LoadData();
                }
                catch (Exception ex)
                {
                    // Handle errors
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }

        }

        private void OpenSales_Click(object sender, EventArgs e)
        {
            SalesPanel.Visible = true;
            PurchasePanel.Visible = false;
        }

        private void OpenPurchase_Click(object sender, EventArgs e)
        {
            SalesPanel.Visible = false;
            PurchasePanel.Visible = true;
        }

        private void PurchaseSelectProduct_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void loadProducts()
        {
            // Connection string for XAMPP
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            // SQL query to retrieve product names
            string query = "SELECT Name FROM products";
            // Establish the connection
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    connection.Open();
                    // Create a MySqlCommand to execute the query
                    using (MySqlCommand cmd = new MySqlCommand(query, connection))
                    {
                        // Create a MySqlDataReader to read the results
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Clear existing items
                            PurchaseSelectProduct.Items.Clear();
                            // Read each row
                            while (reader.Read())
                            {
                                // Add the product name to the ComboBox
                                PurchaseSelectProduct.Items.Add(reader.GetString("Name"));
                                SalesSelectProduct.Items.Add(reader.GetString("Name"));
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Handle exceptions
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";

            // Retrieve values from form controls
            string customerName = SalesCustomer.Text;
            string selectedProduct = SalesSelectProduct.SelectedItem?.ToString();
            string quantityText = SalesQuantity.Text;
            int quantity;

            // Validate input
            if (string.IsNullOrWhiteSpace(customerName) || string.IsNullOrWhiteSpace(selectedProduct) ||
                string.IsNullOrWhiteSpace(quantityText) || !int.TryParse(quantityText, out quantity))
            {
                MessageBox.Show("Please fill in all fields and enter a valid quantity.");
                return;
            }

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    connection.Open();

                    // Retrieve ProductID and current StockQuantity from the products table
                    string productQuery = "SELECT ProductID, StockQuantity FROM products WHERE Name = @ProductName";
                    int productId = -1;
                    int currentStock = 0;

                    using (MySqlCommand cmd = new MySqlCommand(productQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@ProductName", selectedProduct);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                productId = reader.GetInt32("ProductID");
                                currentStock = reader.GetInt32("StockQuantity");
                            }
                        }
                    }

                    if (productId == -1)
                    {
                        MessageBox.Show("Product not found.");
                        return;
                    }

                    if (currentStock < quantity)
                    {
                        MessageBox.Show("Insufficient stock. Available quantity: " + currentStock);
                        return;
                    }

                    // Insert the sales order into the transactions table
                    string insertTransactionQuery = @"
                INSERT INTO transactions 
                (ProductID, Quantity, Date, CustomerOrSupplier, TransactionType) 
                VALUES (@ProductID, @Quantity, @Date, @CustomerOrSupplier, @TransactionType)";

                    using (MySqlCommand cmd = new MySqlCommand(insertTransactionQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@ProductID", productId);
                        cmd.Parameters.AddWithValue("@Quantity", quantity);
                        cmd.Parameters.AddWithValue("@Date", DateTime.Now);
                        cmd.Parameters.AddWithValue("@CustomerOrSupplier", customerName);
                        cmd.Parameters.AddWithValue("@TransactionType", "Sale");

                        cmd.ExecuteNonQuery();
                    }

                    // Update StockQuantity in the products table
                    string updateStockQuery = "UPDATE products SET StockQuantity = StockQuantity - @Quantity WHERE ProductID = @ProductID";

                    using (MySqlCommand cmd = new MySqlCommand(updateStockQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@Quantity", quantity);
                        cmd.Parameters.AddWithValue("@ProductID", productId);
                        cmd.ExecuteNonQuery();
                    }

                    // Clear inputs and show success message
                    SalesCustomer.Text = "";
                    SalesSelectProduct.SelectedIndex = -1;
                    SalesQuantity.Text = "";
                    MessageBox.Show("Sales order successfully added to transactions and stock updated.");
                    LoadData(); // Reload the data to refresh the UI
                }
                catch (Exception ex)
                {
                    // Handle errors
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void SearchBtn_Click(object sender, EventArgs e)
        {
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            string searchTerm = SearchBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                MessageBox.Show("Please enter a search term.");
                return;
            }

            // SQL query with LIKE for flexible search
            string query = @"
        SELECT 
            t.TransactionID, 
            p.Name AS ProductName, 
            t.Quantity, 
            t.Date, 
            t.CustomerOrSupplier, 
            t.TransactionType
        FROM 
            transactions t
        JOIN 
            products p ON t.ProductID = p.ProductID
        WHERE 
            p.Name LIKE @SearchTerm OR 
            t.CustomerOrSupplier LIKE @SearchTerm OR 
            t.TransactionType LIKE @SearchTerm";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    connection.Open();

                    // Create a MySQL data adapter with the search query
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(query, connection);
                    dataAdapter.SelectCommand.Parameters.AddWithValue("@SearchTerm", "%" + searchTerm + "%");

                    // Create a DataTable to hold the search results
                    DataTable dataTable = new DataTable();

                    // Fill the DataTable with the results
                    dataAdapter.Fill(dataTable);

                    // Bind the results to the DataGridView
                    TransactionsGrid.DataSource = dataTable;

                    if (dataTable.Rows.Count == 0)
                    {
                        MessageBox.Show("No records found for the search term.");
                    }
                }
                catch (Exception ex)
                {
                    // Handle exceptions
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
    }
}

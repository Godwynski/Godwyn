﻿namespace inventory_ni_gadwin
{
    partial class settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel2 = new Panel();
            panel1 = new Panel();
            label4 = new Label();
            label3 = new Label();
            ConfirmNewPassword = new TextBox();
            MessageText = new Label();
            label1 = new Label();
            OldPassword = new TextBox();
            label2 = new Label();
            NewPassword = new TextBox();
            ChangePassword = new Button();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.None;
            panel2.BackColor = Color.FromArgb(255, 182, 193);
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(panel1);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(ConfirmNewPassword);
            panel2.Controls.Add(MessageText);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(OldPassword);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(NewPassword);
            panel2.Controls.Add(ChangePassword);
            panel2.Location = new Point(250, 95);
            panel2.Name = "panel2";
            panel2.Size = new Size(400, 421);
            panel2.TabIndex = 1;
            // 
            // panel1
            // 
            panel1.Controls.Add(label4);
            panel1.Location = new Point(49, 46);
            panel1.Name = "panel1";
            panel1.Size = new Size(300, 100);
            panel1.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label4.Location = new Point(0, 0);
            label4.Name = "label4";
            label4.Size = new Size(55, 21);
            label4.TabIndex = 0;
            label4.Text = "label4";
            label4.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(49, 258);
            label3.Name = "label3";
            label3.Size = new Size(177, 21);
            label3.TabIndex = 7;
            label3.Text = "Confirm New Password";
            // 
            // ConfirmNewPassword
            // 
            ConfirmNewPassword.BorderStyle = BorderStyle.FixedSingle;
            ConfirmNewPassword.Font = new Font("Segoe UI", 10F);
            ConfirmNewPassword.Location = new Point(49, 282);
            ConfirmNewPassword.Name = "ConfirmNewPassword";
            ConfirmNewPassword.Size = new Size(300, 25);
            ConfirmNewPassword.TabIndex = 8;
            ConfirmNewPassword.UseSystemPasswordChar = true;
            // 
            // MessageText
            // 
            MessageText.AutoSize = true;
            MessageText.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic);
            MessageText.ForeColor = Color.Red;
            MessageText.Location = new Point(49, 346);
            MessageText.Name = "MessageText";
            MessageText.Size = new Size(0, 21);
            MessageText.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(49, 149);
            label1.Name = "label1";
            label1.Size = new Size(109, 21);
            label1.TabIndex = 0;
            label1.Text = "Old Password";
            // 
            // OldPassword
            // 
            OldPassword.BorderStyle = BorderStyle.FixedSingle;
            OldPassword.Font = new Font("Segoe UI", 10F);
            OldPassword.Location = new Point(49, 173);
            OldPassword.Name = "OldPassword";
            OldPassword.Size = new Size(300, 25);
            OldPassword.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(49, 204);
            label2.Name = "label2";
            label2.Size = new Size(115, 21);
            label2.TabIndex = 2;
            label2.Text = "New Password";
            // 
            // NewPassword
            // 
            NewPassword.BorderStyle = BorderStyle.FixedSingle;
            NewPassword.Font = new Font("Segoe UI", 10F);
            NewPassword.Location = new Point(49, 228);
            NewPassword.Name = "NewPassword";
            NewPassword.Size = new Size(300, 25);
            NewPassword.TabIndex = 3;
            NewPassword.UseSystemPasswordChar = true;
            // 
            // ChangePassword
            // 
            ChangePassword.BackColor = Color.FromArgb(255, 105, 180);
            ChangePassword.FlatStyle = FlatStyle.Flat;
            ChangePassword.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            ChangePassword.ForeColor = Color.White;
            ChangePassword.Location = new Point(49, 313);
            ChangePassword.Name = "ChangePassword";
            ChangePassword.Size = new Size(300, 40);
            ChangePassword.TabIndex = 4;
            ChangePassword.Text = "Login";
            ChangePassword.UseVisualStyleBackColor = false;
            // 
            // settings
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(901, 610);
            Controls.Add(panel2);
            Name = "settings";
            Text = "settings";
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel2;
        private Label MessageText;
        private Label label1;
        private TextBox OldPassword;
        private Label label2;
        private TextBox NewPassword;
        private Button ChangePassword;
        private Label label3;
        private TextBox ConfirmNewPassword;
        private Panel panel1;
        private Label label4;
    }
}
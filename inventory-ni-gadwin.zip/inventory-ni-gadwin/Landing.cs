﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Bcpg;


namespace inventory_ni_gadwin
{
    public partial class landing : Form
    {
        private int userID;

        public landing()
        {
            InitializeComponent();
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            string username = LoginUsername.Text.Trim();
            string password = LoginPassword.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageText.Text = "Please enter your username and password.";
                return;
            }

            if (ValidateLogin(username, password))
            {
                MessageBox.Show($"Welcome, {Session.FirstName}!", "Login Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Redirect to another form or perform post-login actions
                this.Hide();
                Inventory inventory = new Inventory();
                inventory.Show();
            }
            else
            {
                MessageText.Text = "Invalid username or password.";
            }
        }

        private bool ValidateLogin(string username, string password)
        {
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    string query = @"
                SELECT 
                    UserID,
                    Username,
                    PasswordHash,
                    Role,
                    first_name,
                    last_name
                FROM 
                    users
                WHERE 
                    Username = @Username";

                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Username", username);

                    MySqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        string dbPasswordHash = reader["PasswordHash"].ToString();

                        // Hash the entered password and compare with the database hash
                        if (HashPassword.Hash(password) == dbPasswordHash)
                        {
                            // Store user information in the session
                            Session.UserID = Convert.ToInt32(reader["UserID"]);
                            Session.Username = reader["Username"].ToString();
                            Session.Role = reader["Role"].ToString();
                            Session.FirstName = reader["first_name"].ToString();
                            Session.LastName = reader["last_name"].ToString();

                            reader.Close();
                            return true; // Login successful
                        }
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }

            return false; // Login failed
        }
    }
}

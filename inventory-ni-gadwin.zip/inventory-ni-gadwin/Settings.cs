﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inventory_ni_gadwin
{
    public partial class settings : Form
    {
        public settings()
        {
            InitializeComponent();
           label4.Text = "Username: " + Session.Username + "\n" +
      "First Name: " + Session.FirstName + "\n" +
      "Last Name: " + Session.LastName + "\n" +
      "Role: " + Session.Role + "\n";
            ;
            label4.Size = new Size(200, 80);
        }

        private void messageTextBox_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿namespace inventory_ni_gadwin
{
    partial class products
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            NavigationBar = new Panel();
            SearchBtn = new Button();
            SearchBox = new TextBox();
            OpenAddPanel = new Button();
            EditProductPanel = new Panel();
            EditProductCategory = new ComboBox();
            EditProductSupplier = new ComboBox();
            label13 = new Label();
            EditProductPrice = new TextBox();
            label10 = new Label();
            EditProductQuantity = new TextBox();
            label2 = new Label();
            panel4 = new Panel();
            CloseEditPanelbtn = new Button();
            label1 = new Label();
            UpdateBtn = new Button();
            EditProductName = new TextBox();
            AddProductPanel = new Panel();
            SelectProductCategory = new ComboBox();
            SelectProductSupplier = new ComboBox();
            label11 = new Label();
            Price = new Label();
            AddProductPrice = new TextBox();
            label9 = new Label();
            AddProductQuantity = new TextBox();
            label6 = new Label();
            label7 = new Label();
            panel5 = new Panel();
            CloseAddPanelbtn = new Button();
            label8 = new Label();
            AddBtn = new Button();
            AddProductName = new TextBox();
            MainPanel = new Panel();
            ProductGrid = new DataGridView();
            panel1 = new Panel();
            NextPage = new Button();
            PreviewsPage = new Button();
            NavigationBar.SuspendLayout();
            EditProductPanel.SuspendLayout();
            panel4.SuspendLayout();
            AddProductPanel.SuspendLayout();
            panel5.SuspendLayout();
            MainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ProductGrid).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // NavigationBar
            // 
            NavigationBar.BackColor = Color.Pink;
            NavigationBar.Controls.Add(SearchBtn);
            NavigationBar.Controls.Add(SearchBox);
            NavigationBar.Controls.Add(OpenAddPanel);
            NavigationBar.Dock = DockStyle.Top;
            NavigationBar.Location = new Point(0, 0);
            NavigationBar.Name = "NavigationBar";
            NavigationBar.Padding = new Padding(10);
            NavigationBar.Size = new Size(798, 55);
            NavigationBar.TabIndex = 2;
            // 
            // SearchBtn
            // 
            SearchBtn.Dock = DockStyle.Left;
            SearchBtn.Location = new Point(614, 10);
            SearchBtn.Name = "SearchBtn";
            SearchBtn.Size = new Size(75, 35);
            SearchBtn.TabIndex = 3;
            SearchBtn.Text = "Search";
            SearchBtn.UseVisualStyleBackColor = true;
            SearchBtn.Click += SearchBtn_Click;
            // 
            // SearchBox
            // 
            SearchBox.Dock = DockStyle.Left;
            SearchBox.Font = new Font("Segoe UI", 15F);
            SearchBox.Location = new Point(85, 10);
            SearchBox.Margin = new Padding(0);
            SearchBox.Name = "SearchBox";
            SearchBox.Size = new Size(529, 34);
            SearchBox.TabIndex = 2;
            // 
            // OpenAddPanel
            // 
            OpenAddPanel.Dock = DockStyle.Left;
            OpenAddPanel.Location = new Point(10, 10);
            OpenAddPanel.Name = "OpenAddPanel";
            OpenAddPanel.Size = new Size(75, 35);
            OpenAddPanel.TabIndex = 0;
            OpenAddPanel.Text = "Add";
            OpenAddPanel.UseVisualStyleBackColor = true;
            OpenAddPanel.Click += addBtn_Click;
            // 
            // EditProductPanel
            // 
            EditProductPanel.BorderStyle = BorderStyle.FixedSingle;
            EditProductPanel.Controls.Add(EditProductCategory);
            EditProductPanel.Controls.Add(EditProductSupplier);
            EditProductPanel.Controls.Add(label13);
            EditProductPanel.Controls.Add(EditProductPrice);
            EditProductPanel.Controls.Add(label10);
            EditProductPanel.Controls.Add(EditProductQuantity);
            EditProductPanel.Controls.Add(label2);
            EditProductPanel.Controls.Add(panel4);
            EditProductPanel.Controls.Add(UpdateBtn);
            EditProductPanel.Controls.Add(EditProductName);
            EditProductPanel.Dock = DockStyle.Right;
            EditProductPanel.Location = new Point(1033, 0);
            EditProductPanel.Name = "EditProductPanel";
            EditProductPanel.Size = new Size(235, 690);
            EditProductPanel.TabIndex = 3;
            EditProductPanel.Visible = false;
            // 
            // EditProductCategory
            // 
            EditProductCategory.FormattingEnabled = true;
            EditProductCategory.Location = new Point(209, 634);
            EditProductCategory.Name = "EditProductCategory";
            EditProductCategory.Size = new Size(215, 23);
            EditProductCategory.TabIndex = 15;
            EditProductCategory.Visible = false;
            // 
            // EditProductSupplier
            // 
            EditProductSupplier.FormattingEnabled = true;
            EditProductSupplier.Location = new Point(209, 662);
            EditProductSupplier.Name = "EditProductSupplier";
            EditProductSupplier.Size = new Size(217, 23);
            EditProductSupplier.TabIndex = 17;
            EditProductSupplier.Visible = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(9, 183);
            label13.Name = "label13";
            label13.Size = new Size(33, 15);
            label13.TabIndex = 14;
            label13.Text = "Price";
            // 
            // EditProductPrice
            // 
            EditProductPrice.Location = new Point(9, 206);
            EditProductPrice.Name = "EditProductPrice";
            EditProductPrice.Size = new Size(217, 23);
            EditProductPrice.TabIndex = 13;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(9, 118);
            label10.Name = "label10";
            label10.Size = new Size(53, 15);
            label10.TabIndex = 8;
            label10.Text = "Quantity";
            // 
            // EditProductQuantity
            // 
            EditProductQuantity.Location = new Point(9, 141);
            EditProductQuantity.Name = "EditProductQuantity";
            EditProductQuantity.Size = new Size(217, 23);
            EditProductQuantity.TabIndex = 7;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(9, 64);
            label2.Name = "label2";
            label2.Size = new Size(84, 15);
            label2.TabIndex = 2;
            label2.Text = "Product Name";
            // 
            // panel4
            // 
            panel4.BackColor = Color.LightPink;
            panel4.Controls.Add(CloseEditPanelbtn);
            panel4.Controls.Add(label1);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(233, 55);
            panel4.TabIndex = 3;
            // 
            // CloseEditPanelbtn
            // 
            CloseEditPanelbtn.BackColor = Color.Transparent;
            CloseEditPanelbtn.Dock = DockStyle.Right;
            CloseEditPanelbtn.FlatAppearance.BorderSize = 0;
            CloseEditPanelbtn.FlatStyle = FlatStyle.Flat;
            CloseEditPanelbtn.Location = new Point(209, 0);
            CloseEditPanelbtn.Name = "CloseEditPanelbtn";
            CloseEditPanelbtn.Size = new Size(24, 55);
            CloseEditPanelbtn.TabIndex = 7;
            CloseEditPanelbtn.Text = "x";
            CloseEditPanelbtn.UseVisualStyleBackColor = false;
            CloseEditPanelbtn.Click += CloseEditPanelbtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(79, 20);
            label1.Name = "label1";
            label1.Size = new Size(72, 15);
            label1.TabIndex = 1;
            label1.Text = "Edit Product";
            // 
            // UpdateBtn
            // 
            UpdateBtn.Location = new Point(79, 251);
            UpdateBtn.Name = "UpdateBtn";
            UpdateBtn.Size = new Size(75, 23);
            UpdateBtn.TabIndex = 2;
            UpdateBtn.Text = "Update";
            UpdateBtn.Click += UpdateBtn_Click;
            // 
            // EditProductName
            // 
            EditProductName.Location = new Point(9, 87);
            EditProductName.Name = "EditProductName";
            EditProductName.Size = new Size(217, 23);
            EditProductName.TabIndex = 0;
            // 
            // AddProductPanel
            // 
            AddProductPanel.BorderStyle = BorderStyle.FixedSingle;
            AddProductPanel.Controls.Add(SelectProductCategory);
            AddProductPanel.Controls.Add(SelectProductSupplier);
            AddProductPanel.Controls.Add(label11);
            AddProductPanel.Controls.Add(Price);
            AddProductPanel.Controls.Add(AddProductPrice);
            AddProductPanel.Controls.Add(label9);
            AddProductPanel.Controls.Add(AddProductQuantity);
            AddProductPanel.Controls.Add(label6);
            AddProductPanel.Controls.Add(label7);
            AddProductPanel.Controls.Add(panel5);
            AddProductPanel.Controls.Add(AddBtn);
            AddProductPanel.Controls.Add(AddProductName);
            AddProductPanel.Dock = DockStyle.Right;
            AddProductPanel.Location = new Point(798, 0);
            AddProductPanel.Name = "AddProductPanel";
            AddProductPanel.Size = new Size(235, 690);
            AddProductPanel.TabIndex = 4;
            AddProductPanel.Visible = false;
            // 
            // SelectProductCategory
            // 
            SelectProductCategory.FormattingEnabled = true;
            SelectProductCategory.Location = new Point(11, 263);
            SelectProductCategory.Name = "SelectProductCategory";
            SelectProductCategory.Size = new Size(215, 23);
            SelectProductCategory.TabIndex = 14;
            // 
            // SelectProductSupplier
            // 
            SelectProductSupplier.FormattingEnabled = true;
            SelectProductSupplier.Location = new Point(11, 329);
            SelectProductSupplier.Name = "SelectProductSupplier";
            SelectProductSupplier.Size = new Size(215, 23);
            SelectProductSupplier.TabIndex = 13;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(11, 240);
            label11.Name = "label11";
            label11.Size = new Size(55, 15);
            label11.TabIndex = 12;
            label11.Text = "Category";
            // 
            // Price
            // 
            Price.AutoSize = true;
            Price.Location = new Point(11, 183);
            Price.Name = "Price";
            Price.Size = new Size(33, 15);
            Price.TabIndex = 10;
            Price.Text = "Price";
            // 
            // AddProductPrice
            // 
            AddProductPrice.Location = new Point(11, 206);
            AddProductPrice.Name = "AddProductPrice";
            AddProductPrice.Size = new Size(217, 23);
            AddProductPrice.TabIndex = 9;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(11, 118);
            label9.Name = "label9";
            label9.Size = new Size(53, 15);
            label9.TabIndex = 8;
            label9.Text = "Quantity";
            // 
            // AddProductQuantity
            // 
            AddProductQuantity.Location = new Point(11, 141);
            AddProductQuantity.Name = "AddProductQuantity";
            AddProductQuantity.Size = new Size(217, 23);
            AddProductQuantity.TabIndex = 7;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(9, 306);
            label6.Name = "label6";
            label6.Size = new Size(50, 15);
            label6.TabIndex = 5;
            label6.Text = "Supplier";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(9, 64);
            label7.Name = "label7";
            label7.Size = new Size(84, 15);
            label7.TabIndex = 2;
            label7.Text = "Product Name";
            // 
            // panel5
            // 
            panel5.BackColor = Color.LightPink;
            panel5.Controls.Add(CloseAddPanelbtn);
            panel5.Controls.Add(label8);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(233, 55);
            panel5.TabIndex = 3;
            // 
            // CloseAddPanelbtn
            // 
            CloseAddPanelbtn.BackColor = Color.Transparent;
            CloseAddPanelbtn.Dock = DockStyle.Right;
            CloseAddPanelbtn.FlatAppearance.BorderSize = 0;
            CloseAddPanelbtn.FlatStyle = FlatStyle.Flat;
            CloseAddPanelbtn.Location = new Point(209, 0);
            CloseAddPanelbtn.Name = "CloseAddPanelbtn";
            CloseAddPanelbtn.Size = new Size(24, 55);
            CloseAddPanelbtn.TabIndex = 7;
            CloseAddPanelbtn.Text = "x";
            CloseAddPanelbtn.UseVisualStyleBackColor = false;
            CloseAddPanelbtn.Click += CloseAddPanelbtn_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(76, 21);
            label8.Name = "label8";
            label8.Size = new Size(74, 15);
            label8.TabIndex = 1;
            label8.Text = "Add Product";
            // 
            // AddBtn
            // 
            AddBtn.Location = new Point(79, 383);
            AddBtn.Name = "AddBtn";
            AddBtn.Size = new Size(75, 23);
            AddBtn.TabIndex = 2;
            AddBtn.Text = "Add";
            AddBtn.UseVisualStyleBackColor = true;
            AddBtn.Click += AddBtn_Click_1;
            // 
            // AddProductName
            // 
            AddProductName.Location = new Point(9, 87);
            AddProductName.Name = "AddProductName";
            AddProductName.Size = new Size(217, 23);
            AddProductName.TabIndex = 0;
            // 
            // MainPanel
            // 
            MainPanel.Controls.Add(ProductGrid);
            MainPanel.Controls.Add(panel1);
            MainPanel.Dock = DockStyle.Fill;
            MainPanel.Location = new Point(0, 55);
            MainPanel.Name = "MainPanel";
            MainPanel.Size = new Size(798, 635);
            MainPanel.TabIndex = 5;
            // 
            // ProductGrid
            // 
            ProductGrid.AllowUserToAddRows = false;
            ProductGrid.AllowUserToDeleteRows = false;
            ProductGrid.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(245, 245, 245);
            ProductGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            ProductGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            ProductGrid.BackgroundColor = Color.Pink;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(240, 240, 240);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = Color.PaleVioletRed;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            ProductGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.PaleVioletRed;
            dataGridViewCellStyle3.SelectionForeColor = Color.White;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            ProductGrid.DefaultCellStyle = dataGridViewCellStyle3;
            ProductGrid.Dock = DockStyle.Fill;
            ProductGrid.GridColor = Color.RosyBrown;
            ProductGrid.ImeMode = ImeMode.NoControl;
            ProductGrid.Location = new Point(0, 0);
            ProductGrid.MultiSelect = false;
            ProductGrid.Name = "ProductGrid";
            ProductGrid.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = SystemColors.Control;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = Color.PaleVioletRed;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            ProductGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            ProductGrid.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            ProductGrid.RowTemplate.Height = 40;
            ProductGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            ProductGrid.ShowCellErrors = false;
            ProductGrid.ShowCellToolTips = false;
            ProductGrid.ShowEditingIcon = false;
            ProductGrid.Size = new Size(798, 580);
            ProductGrid.TabIndex = 1;
            ProductGrid.CellContentClick += ProductGrid_CellContentClick;
            // 
            // panel1
            // 
            panel1.Controls.Add(NextPage);
            panel1.Controls.Add(PreviewsPage);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 580);
            panel1.Name = "panel1";
            panel1.Size = new Size(798, 55);
            panel1.TabIndex = 0;
            // 
            // NextPage
            // 
            NextPage.Location = new Point(59, 16);
            NextPage.Name = "NextPage";
            NextPage.Size = new Size(36, 23);
            NextPage.TabIndex = 1;
            NextPage.Text = ">";
            NextPage.UseVisualStyleBackColor = true;
            NextPage.Click += NextPage_Click;
            // 
            // PreviewsPage
            // 
            PreviewsPage.Location = new Point(13, 16);
            PreviewsPage.Name = "PreviewsPage";
            PreviewsPage.Size = new Size(40, 23);
            PreviewsPage.TabIndex = 0;
            PreviewsPage.Text = "<";
            PreviewsPage.UseVisualStyleBackColor = true;
            PreviewsPage.Click += PreviewsPage_Click;
            // 
            // products
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1268, 690);
            Controls.Add(MainPanel);
            Controls.Add(NavigationBar);
            Controls.Add(AddProductPanel);
            Controls.Add(EditProductPanel);
            FormBorderStyle = FormBorderStyle.None;
            Name = "products";
            Text = "products";
            NavigationBar.ResumeLayout(false);
            NavigationBar.PerformLayout();
            EditProductPanel.ResumeLayout(false);
            EditProductPanel.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            AddProductPanel.ResumeLayout(false);
            AddProductPanel.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            MainPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)ProductGrid).EndInit();
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Panel NavigationBar;
        private Button OpenAddPanel;
        private Panel EditProductPanel;
        private Button UpdateBtn;
        private TextBox EditProductName;
        private Panel panel4;
        private Label label2;
        private Label label1;
        private Button CloseEditPanelbtn;
        private Panel AddProductPanel;
        private Label label6;
        private Label label7;
        private Panel panel5;
        private Button CloseAddPanelbtn;
        private Button AddBtn;
        private TextBox AddProductName;
        private Button SearchBtn;
        private TextBox SearchBox;
        private Label label10;
        private TextBox EditProductQuantity;
        private Label label9;
        private TextBox AddProductQuantity;
        private Label label8;
        private Panel MainPanel;
        private DataGridView ProductGrid;
        private Panel panel1;
        private Button NextPage;
        private Button PreviewsPage;
        private Label label11;
        private Label Price;
        private TextBox AddProductPrice;
        private Label label13;
        private TextBox EditProductPrice;
        private ComboBox EditProductSupplier;
        private ComboBox SelectProductSupplier;
        private ComboBox EditProductCategory;
        private ComboBox SelectProductCategory;
    }
}
﻿namespace inventory_ni_gadwin
{
    partial class Inventory
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            panel2 = new Panel();
            button1 = new Button();
            btnSettings = new Button();
            btnUserMan = new Button();
            btnProducts = new Button();
            Supplier = new Button();
            btnStoTra = new Button();
            panel3 = new Panel();
            panelMain = new Panel();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Thistle;
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(btnSettings);
            panel1.Controls.Add(btnUserMan);
            panel1.Controls.Add(btnProducts);
            panel1.Controls.Add(Supplier);
            panel1.Controls.Add(btnStoTra);
            panel1.Controls.Add(panel3);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(183, 681);
            panel1.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.Controls.Add(button1);
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 581);
            panel2.Name = "panel2";
            panel2.Size = new Size(183, 100);
            panel2.TabIndex = 8;
            // 
            // button1
            // 
            button1.BackColor = Color.Pink;
            button1.Dock = DockStyle.Top;
            button1.Location = new Point(0, 0);
            button1.Name = "button1";
            button1.Size = new Size(183, 51);
            button1.TabIndex = 2;
            button1.Text = "Logout";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // btnSettings
            // 
            btnSettings.BackColor = Color.Pink;
            btnSettings.Dock = DockStyle.Top;
            btnSettings.Location = new Point(0, 258);
            btnSettings.Name = "btnSettings";
            btnSettings.Size = new Size(183, 51);
            btnSettings.TabIndex = 7;
            btnSettings.Text = "Settings";
            btnSettings.UseVisualStyleBackColor = false;
            btnSettings.Click += btnSettings_Click;
            // 
            // btnUserMan
            // 
            btnUserMan.BackColor = Color.Pink;
            btnUserMan.Dock = DockStyle.Top;
            btnUserMan.Location = new Point(0, 207);
            btnUserMan.Name = "btnUserMan";
            btnUserMan.Size = new Size(183, 51);
            btnUserMan.TabIndex = 6;
            btnUserMan.Text = "User Management";
            btnUserMan.UseVisualStyleBackColor = false;
            btnUserMan.Click += btnUserMan_Click;
            // 
            // btnProducts
            // 
            btnProducts.BackColor = Color.Pink;
            btnProducts.Dock = DockStyle.Top;
            btnProducts.Location = new Point(0, 156);
            btnProducts.Name = "btnProducts";
            btnProducts.Size = new Size(183, 51);
            btnProducts.TabIndex = 2;
            btnProducts.Text = "Product Management";
            btnProducts.UseVisualStyleBackColor = false;
            btnProducts.Click += btnProducts_Click;
            // 
            // Supplier
            // 
            Supplier.BackColor = Color.Pink;
            Supplier.Dock = DockStyle.Top;
            Supplier.Location = new Point(0, 105);
            Supplier.Name = "Supplier";
            Supplier.Size = new Size(183, 51);
            Supplier.TabIndex = 4;
            Supplier.Text = "Suppliers";
            Supplier.UseVisualStyleBackColor = false;
            Supplier.Click += Supplier_Click;
            // 
            // btnStoTra
            // 
            btnStoTra.BackColor = Color.Pink;
            btnStoTra.Dock = DockStyle.Top;
            btnStoTra.Location = new Point(0, 54);
            btnStoTra.Name = "btnStoTra";
            btnStoTra.Size = new Size(183, 51);
            btnStoTra.TabIndex = 3;
            btnStoTra.Text = "Stock Transactions";
            btnStoTra.UseVisualStyleBackColor = false;
            btnStoTra.Click += btnStoTra_Click;
            // 
            // panel3
            // 
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(183, 54);
            panel3.TabIndex = 9;
            // 
            // panelMain
            // 
            panelMain.AutoScroll = true;
            panelMain.Dock = DockStyle.Fill;
            panelMain.Location = new Point(183, 0);
            panelMain.Name = "panelMain";
            panelMain.Size = new Size(1081, 681);
            panelMain.TabIndex = 2;
            // 
            // Inventory
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1264, 681);
            Controls.Add(panelMain);
            Controls.Add(panel1);
            MinimumSize = new Size(1280, 720);
            Name = "Inventory";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Inventory";
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panelMain;
        private Button btnUserMan;
        private Button Supplier;
        private Button btnStoTra;
        private Button btnProducts;
        private Button btnSettings;
        private Panel panel2;
        private Button button1;
        private Panel panel3;
    }
}

﻿namespace inventory_ni_gadwin
{
    partial class landing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            panel2 = new Panel();
            MessageText = new Label();
            label1 = new Label();
            LoginUsername = new TextBox();
            label2 = new Label();
            LoginPassword = new TextBox();
            button1 = new Button();
            label3 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(255, 192, 203);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1136, 658);
            panel1.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.None;
            panel2.BackColor = Color.FromArgb(255, 182, 193);
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(label3);
            panel2.Controls.Add(MessageText);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(LoginUsername);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(LoginPassword);
            panel2.Controls.Add(button1);
            panel2.Location = new Point(353, 57);
            panel2.Name = "panel2";
            panel2.Size = new Size(400, 421);
            panel2.TabIndex = 0;
            // 
            // MessageText
            // 
            MessageText.AutoSize = true;
            MessageText.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic);
            MessageText.ForeColor = Color.Red;
            MessageText.Location = new Point(49, 346);
            MessageText.Name = "MessageText";
            MessageText.Size = new Size(0, 21);
            MessageText.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(49, 149);
            label1.Name = "label1";
            label1.Size = new Size(82, 21);
            label1.TabIndex = 0;
            label1.Text = "Username";
            // 
            // LoginUsername
            // 
            LoginUsername.BorderStyle = BorderStyle.FixedSingle;
            LoginUsername.Font = new Font("Segoe UI", 10F);
            LoginUsername.Location = new Point(49, 173);
            LoginUsername.Name = "LoginUsername";
            LoginUsername.Size = new Size(300, 25);
            LoginUsername.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(49, 229);
            label2.Name = "label2";
            label2.Size = new Size(79, 21);
            label2.TabIndex = 2;
            label2.Text = "Password";
            // 
            // LoginPassword
            // 
            LoginPassword.BorderStyle = BorderStyle.FixedSingle;
            LoginPassword.Font = new Font("Segoe UI", 10F);
            LoginPassword.Location = new Point(49, 253);
            LoginPassword.Name = "LoginPassword";
            LoginPassword.Size = new Size(300, 25);
            LoginPassword.TabIndex = 3;
            LoginPassword.UseSystemPasswordChar = true;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(255, 105, 180);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(49, 313);
            button1.Name = "button1";
            button1.Size = new Size(300, 40);
            button1.TabIndex = 4;
            button1.Text = "Login";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.HotPink;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(46, 45);
            label3.Name = "label3";
            label3.Padding = new Padding(20);
            label3.Size = new Size(310, 82);
            label3.TabIndex = 6;
            label3.Text = "Gadgets and Accessories Warehouse\r\nInventory Management\r\n";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // landing
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1136, 658);
            Controls.Add(panel1);
            Name = "landing";
            Text = "Landing";
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label label1;
        private TextBox LoginUsername;
        private Label label2;
        private TextBox LoginPassword;
        private Button button1;
        private Label MessageText;
        private Label label3;
    }
}

﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inventory_ni_gadwin
{
    public partial class usermanagement : Form
    {
        int selecteduserid;
        public usermanagement()
        {
            InitializeComponent();
            LoadData();
            AddActionButtons();
        }


        private void LoadData()
        {
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Query to count total rows
                    string countQuery = "SELECT COUNT(*) FROM users";
                    MySqlCommand countCmd = new MySqlCommand(countQuery, conn);
                    totalRows = Convert.ToInt32(countCmd.ExecuteScalar());

                    // Calculate total pages
                    int totalPages = (int)Math.Ceiling((double)totalRows / pageSize);

                    // Ensure currentPage stays within bounds
                    if (currentPage < 0)
                        currentPage = 0;
                    else if (currentPage >= totalPages)
                        currentPage = totalPages - 1;

                    // Query for paginated data
                    string query = $@"
                SELECT 
                    users.userID,
                    users.Username,
                    users.Role,
                    users.first_name,
                    users.last_name
                FROM 
                    users
                LIMIT {pageSize} OFFSET {currentPage * pageSize}";

                    MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    UserGrid.DataSource = dataTable; // Bind to DataGridView
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }


        private void ClearFields()
        {
            // Clear textboxes
            EditUserName.Clear();
            EditFirstName.Clear();
            EditLastName.Clear();
            EditSelectRole.Items.Clear();
        }


        private void AddBtn_Click_2(object sender, EventArgs e)
        {
            string Username = AddUsername.Text;
            string firstName = AddFirstName.Text;
            string lastName = AddLastName.Text;
            string addSelectRole = AddSelectRole.SelectedItem?.ToString();
            string password = HashPassword.Hash("Password"); // Default password

            if (string.IsNullOrWhiteSpace(Username) || string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(lastName) || addSelectRole == null)
            {
                MessageBox.Show("Please fill in all fields and select both category and supplier.");
                return;
            }

            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();


                // Insert Product
                string insertQuery = @"INSERT INTO users (Username, PasswordHash, Role, first_name, last_name)
                               VALUES (@Username, @Password, @Role, @FirstName, @LastName)";
                using (MySqlCommand cmd = new MySqlCommand(insertQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@Username", Username);
                    cmd.Parameters.AddWithValue("@Password", password);
                    cmd.Parameters.AddWithValue("@Role", addSelectRole);
                    cmd.Parameters.AddWithValue("@FirstName", firstName);
                    cmd.Parameters.AddWithValue("@LastName", lastName);

                    cmd.ExecuteNonQuery();
                }

                AddFirstName.Text = "";
                AddLastName.Text = "";
                AddSelectRole.SelectedIndex = -1;
                AddUsername.Text = "";
                MessageBox.Show("User Added Succesfully! The default password is 'Password'");
                LoadData();
            }
        } //Goods na to

        private void OpenAddPanel_Click(object sender, EventArgs e)
        {
            AddUserPanel.Visible = true;
            EditUserPanel.Visible = false;
        }
        
        private void CloseAddPanelbtn_Click(object sender, EventArgs e)
        {
            AddUserPanel.Visible = false;
        }
        private void CloseEditPanelbtn_Click(object sender, EventArgs e)
        {
            EditUserPanel.Visible = false;
        }

        private void ProductGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int userId = Convert.ToInt32(UserGrid.Rows[e.RowIndex].Cells["UserID"].Value);
            selecteduserid = userId;

            if (e.RowIndex >= 0) // Ensure it's not a header row
            {
                var cellValue = UserGrid.Rows[e.RowIndex].Cells["UserID"].Value;

                string id = cellValue.ToString();

                if (UserGrid.Columns[e.ColumnIndex].Name == "Edit")
                {
                    LoadUserDetails(userId);
                    AddUserPanel.Visible = false;
                    EditUserPanel.Visible = true;
                }
                else if (UserGrid.Columns[e.ColumnIndex].Name == "Delete")
                {
                    DeleteRow(id);
                }
                else if (UserGrid.Columns[e.ColumnIndex].Name == "Reset Password")
                {
                    ResetPassword(int.Parse(id));
                }
            }
        }

        private void ResetPassword(int userId)
        {
            string newPassword = "Password";
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Hash the new password
                    string hashedPassword = HashPassword.Hash(newPassword);

                    // Update query to reset the password
                    string query = @"
                UPDATE users
                SET PasswordHash = @PasswordHash
                WHERE UserID = @UserID";

                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@PasswordHash", hashedPassword);
                    cmd.Parameters.AddWithValue("@UserID", userId);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Password has been reset successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Failed to reset the password. User not found.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void SearchUserData()
        {
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Query to count total rows based on search criteria
                    string countQuery = @"
            SELECT COUNT(*) 
            FROM users
            WHERE 
                LOWER(users.Username) LIKE LOWER(@SearchText) OR
                LOWER(users.Role) LIKE LOWER(@SearchText) OR
                LOWER(users.first_name) LIKE LOWER(@SearchText) OR
                LOWER(users.last_name) LIKE LOWER(@SearchText)";
                    MySqlCommand countCmd = new MySqlCommand(countQuery, conn);
                    countCmd.Parameters.AddWithValue("@SearchText", $"%{SearchBox.Text.Trim()}%");
                    totalRows = Convert.ToInt32(countCmd.ExecuteScalar());

                    // Calculate total pages
                    int totalPages = (int)Math.Ceiling((double)totalRows / pageSize);

                    // Ensure currentPage stays within bounds
                    if (currentPage < 0)
                        currentPage = 0;
                    else if (currentPage >= totalPages && totalPages > 0)
                        currentPage = totalPages - 1;

                    // Query for paginated data with search filter
                    string query = $@"
            SELECT 
                users.userID,
                users.Username,
                users.Role,
                users.first_name,
                users.last_name
            FROM 
                users
            WHERE 
                LOWER(users.Username) LIKE LOWER(@SearchText) OR
                LOWER(users.Role) LIKE LOWER(@SearchText) OR
                LOWER(users.first_name) LIKE LOWER(@SearchText) OR
                LOWER(users.last_name) LIKE LOWER(@SearchText)
            LIMIT @PageSize OFFSET @Offset";

                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@SearchText", $"%{SearchBox.Text.Trim()}%");
                    cmd.Parameters.AddWithValue("@PageSize", pageSize);
                    cmd.Parameters.AddWithValue("@Offset", currentPage * pageSize);

                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    UserGrid.DataSource = dataTable; // Bind to DataGridView
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }





        private void LoadUserDetails(int userId)
        {
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    // Query to fetch user details
                    string query = @"SELECT 
                                u.Username,
                                u.Role,
                                u.first_name AS FirstName,
                                u.last_name AS LastName
                            FROM users u
                            WHERE u.UserID = @UserID";

                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@UserID", userId);

                    MySqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        EditUserName.Text = reader["Username"].ToString();
                        EditSelectRole.Text = reader["Role"].ToString();
                        EditFirstName.Text = reader["FirstName"].ToString();
                        EditLastName.Text = reader["LastName"].ToString();
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }

        private void UpdateUserDetails(int userId)
        {
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    // Query to update user details
                    string query = @"UPDATE users 
                             SET 
                                 Username = @Username,
                                 Role = @Role,
                                 first_name = @FirstName,
                                 last_name = @LastName
                             WHERE UserID = @UserID";

                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@UserID", userId);
                    cmd.Parameters.AddWithValue("@Username", EditUserName.Text.Trim());
                    cmd.Parameters.AddWithValue("@Role", EditSelectRole.Text.Trim());
                    cmd.Parameters.AddWithValue("@FirstName", EditFirstName.Text.Trim());
                    cmd.Parameters.AddWithValue("@LastName", EditLastName.Text.Trim());

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("User details updated successfully!");
                        LoadData();
                        ClearFields();
                    }
                    else
                    {
                        MessageBox.Show("No changes were made.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }

        private void DeleteRow(string id)
        {
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                // Delete the selected row
                string deleteQuery = "DELETE FROM users WHERE userID = @UserID";
                using (MySqlCommand cmd = new MySqlCommand(deleteQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@UserID", id);
                    cmd.ExecuteNonQuery();
                }
                LoadData();
            }
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            UpdateUserDetails(selecteduserid);
        }
        private int currentPage = 0;
        private int pageSize = 20; // Number of rows per page
        private int totalRows = 0; // Total number of rows (to be calculated)
        private void NextPage_Click(object sender, EventArgs e)
        {
            if ((currentPage + 1) * pageSize < totalRows)
            {
                currentPage++;
                LoadData();
            }
            else
            {
                MessageBox.Show("You are on the last page.");
            }
        }

        private void PreviewsPage_Click(object sender, EventArgs e)
        {
            if (currentPage > 0)
            {
                currentPage--;
                LoadData();
            }
            else
            {
                MessageBox.Show("You are on the first page.");
            }
        }

        private void SearchBtn_Click(object sender, EventArgs e)
        {
            SearchUserData();
        }
        private void AddActionButtons()
        {
            // Edit button
            DataGridViewButtonColumn editButton = new DataGridViewButtonColumn
            {
                Name = "Edit",
                HeaderText = "Edit",
                Text = "Edit",
                UseColumnTextForButtonValue = true
            };
            UserGrid.Columns.Add(editButton);

            // Delete button
            DataGridViewButtonColumn deleteButton = new DataGridViewButtonColumn
            {
                Name = "Delete",
                HeaderText = "Delete",
                Text = "Delete",
                UseColumnTextForButtonValue = true

            };
            UserGrid.Columns.Add(deleteButton);

            DataGridViewButtonColumn resetPassword = new DataGridViewButtonColumn
            {
                Name = "Reset Password",
                HeaderText = "Reset Password",
                Text = "Reset",
                UseColumnTextForButtonValue = true

            };
            UserGrid.Columns.Add(resetPassword);
        }
    }
}

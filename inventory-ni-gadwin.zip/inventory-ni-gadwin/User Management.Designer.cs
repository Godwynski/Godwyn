﻿namespace inventory_ni_gadwin
{
    partial class usermanagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            EditUserName = new TextBox();
            label5 = new Label();
            EditFirstName = new TextBox();
            label4 = new Label();
            EditLastName = new TextBox();
            label3 = new Label();
            label2 = new Label();
            EditSelectRole = new ComboBox();
            EditUserPanel = new Panel();
            ffsfsdf = new Panel();
            CloseEditPanelbtn = new Button();
            label1 = new Label();
            UpdateBtn = new Button();
            NavigationBar = new Panel();
            SearchBtn = new Button();
            SearchBox = new TextBox();
            OpenAddPanel = new Button();
            panel1 = new Panel();
            NextPage = new Button();
            PreviewsPage = new Button();
            MainPanel = new Panel();
            UserGrid = new DataGridView();
            AddUsername = new TextBox();
            AddLastName = new TextBox();
            Price = new Label();
            label11 = new Label();
            AddSelectRole = new ComboBox();
            AddUserPanel = new Panel();
            label9 = new Label();
            AddFirstName = new TextBox();
            label7 = new Label();
            panel5 = new Panel();
            CloseAddPanelbtn = new Button();
            label8 = new Label();
            AddBtn = new Button();
            EditUserPanel.SuspendLayout();
            ffsfsdf.SuspendLayout();
            NavigationBar.SuspendLayout();
            panel1.SuspendLayout();
            MainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)UserGrid).BeginInit();
            AddUserPanel.SuspendLayout();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // EditUserName
            // 
            EditUserName.Location = new Point(5, 87);
            EditUserName.Name = "EditUserName";
            EditUserName.Size = new Size(217, 23);
            EditUserName.TabIndex = 19;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(5, 64);
            label5.Name = "label5";
            label5.Size = new Size(60, 15);
            label5.TabIndex = 20;
            label5.Text = "Username";
            // 
            // EditFirstName
            // 
            EditFirstName.Location = new Point(7, 141);
            EditFirstName.Name = "EditFirstName";
            EditFirstName.Size = new Size(217, 23);
            EditFirstName.TabIndex = 21;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(7, 118);
            label4.Name = "label4";
            label4.Size = new Size(64, 15);
            label4.TabIndex = 22;
            label4.Text = "First Name";
            // 
            // EditLastName
            // 
            EditLastName.Location = new Point(7, 206);
            EditLastName.Name = "EditLastName";
            EditLastName.Size = new Size(217, 23);
            EditLastName.TabIndex = 23;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(7, 183);
            label3.Name = "label3";
            label3.Size = new Size(63, 15);
            label3.TabIndex = 24;
            label3.Text = "Last Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(7, 240);
            label2.Name = "label2";
            label2.Size = new Size(30, 15);
            label2.TabIndex = 25;
            label2.Text = "Role";
            // 
            // EditSelectRole
            // 
            EditSelectRole.DropDownStyle = ComboBoxStyle.DropDownList;
            EditSelectRole.FormattingEnabled = true;
            EditSelectRole.Items.AddRange(new object[] { "Admin", "Manager", "Staff" });
            EditSelectRole.Location = new Point(7, 263);
            EditSelectRole.Name = "EditSelectRole";
            EditSelectRole.Size = new Size(215, 23);
            EditSelectRole.TabIndex = 26;
            EditSelectRole.UseWaitCursor = true;
            // 
            // EditUserPanel
            // 
            EditUserPanel.BorderStyle = BorderStyle.FixedSingle;
            EditUserPanel.Controls.Add(EditSelectRole);
            EditUserPanel.Controls.Add(label2);
            EditUserPanel.Controls.Add(label3);
            EditUserPanel.Controls.Add(EditLastName);
            EditUserPanel.Controls.Add(label4);
            EditUserPanel.Controls.Add(EditFirstName);
            EditUserPanel.Controls.Add(label5);
            EditUserPanel.Controls.Add(EditUserName);
            EditUserPanel.Controls.Add(ffsfsdf);
            EditUserPanel.Controls.Add(UpdateBtn);
            EditUserPanel.Dock = DockStyle.Right;
            EditUserPanel.Location = new Point(1061, 55);
            EditUserPanel.Name = "EditUserPanel";
            EditUserPanel.Size = new Size(235, 572);
            EditUserPanel.TabIndex = 7;
            EditUserPanel.Visible = false;
            // 
            // ffsfsdf
            // 
            ffsfsdf.BackColor = Color.LightPink;
            ffsfsdf.Controls.Add(CloseEditPanelbtn);
            ffsfsdf.Controls.Add(label1);
            ffsfsdf.Dock = DockStyle.Top;
            ffsfsdf.Location = new Point(0, 0);
            ffsfsdf.Name = "ffsfsdf";
            ffsfsdf.Size = new Size(233, 55);
            ffsfsdf.TabIndex = 3;
            // 
            // CloseEditPanelbtn
            // 
            CloseEditPanelbtn.BackColor = Color.Transparent;
            CloseEditPanelbtn.Dock = DockStyle.Right;
            CloseEditPanelbtn.FlatAppearance.BorderSize = 0;
            CloseEditPanelbtn.FlatStyle = FlatStyle.Flat;
            CloseEditPanelbtn.Location = new Point(209, 0);
            CloseEditPanelbtn.Name = "CloseEditPanelbtn";
            CloseEditPanelbtn.Size = new Size(24, 55);
            CloseEditPanelbtn.TabIndex = 7;
            CloseEditPanelbtn.Text = "x";
            CloseEditPanelbtn.UseVisualStyleBackColor = false;
            CloseEditPanelbtn.Click += CloseEditPanelbtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(79, 20);
            label1.Name = "label1";
            label1.Size = new Size(53, 15);
            label1.TabIndex = 1;
            label1.Text = "Edit User";
            // 
            // UpdateBtn
            // 
            UpdateBtn.Location = new Point(76, 313);
            UpdateBtn.Name = "UpdateBtn";
            UpdateBtn.Size = new Size(75, 23);
            UpdateBtn.TabIndex = 2;
            UpdateBtn.Text = "Update";
            UpdateBtn.Click += UpdateBtn_Click;
            // 
            // NavigationBar
            // 
            NavigationBar.BackColor = Color.Pink;
            NavigationBar.Controls.Add(SearchBtn);
            NavigationBar.Controls.Add(SearchBox);
            NavigationBar.Controls.Add(OpenAddPanel);
            NavigationBar.Dock = DockStyle.Top;
            NavigationBar.Location = new Point(0, 0);
            NavigationBar.Name = "NavigationBar";
            NavigationBar.Padding = new Padding(10);
            NavigationBar.Size = new Size(1296, 55);
            NavigationBar.TabIndex = 2;
            // 
            // SearchBtn
            // 
            SearchBtn.Dock = DockStyle.Left;
            SearchBtn.Location = new Point(614, 10);
            SearchBtn.Name = "SearchBtn";
            SearchBtn.Size = new Size(75, 35);
            SearchBtn.TabIndex = 3;
            SearchBtn.Text = "Search";
            SearchBtn.UseVisualStyleBackColor = true;
            SearchBtn.Click += SearchBtn_Click;
            // 
            // SearchBox
            // 
            SearchBox.Dock = DockStyle.Left;
            SearchBox.Font = new Font("Segoe UI", 15F);
            SearchBox.Location = new Point(85, 10);
            SearchBox.Margin = new Padding(0);
            SearchBox.Name = "SearchBox";
            SearchBox.Size = new Size(529, 34);
            SearchBox.TabIndex = 2;
            // 
            // OpenAddPanel
            // 
            OpenAddPanel.Dock = DockStyle.Left;
            OpenAddPanel.Location = new Point(10, 10);
            OpenAddPanel.Name = "OpenAddPanel";
            OpenAddPanel.Size = new Size(75, 35);
            OpenAddPanel.TabIndex = 0;
            OpenAddPanel.Text = "Add";
            OpenAddPanel.UseVisualStyleBackColor = true;
            OpenAddPanel.Click += OpenAddPanel_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(NextPage);
            panel1.Controls.Add(PreviewsPage);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 517);
            panel1.Name = "panel1";
            panel1.Size = new Size(826, 55);
            panel1.TabIndex = 0;
            // 
            // NextPage
            // 
            NextPage.Location = new Point(59, 16);
            NextPage.Name = "NextPage";
            NextPage.Size = new Size(36, 23);
            NextPage.TabIndex = 1;
            NextPage.Text = ">";
            NextPage.UseVisualStyleBackColor = true;
            NextPage.Click += NextPage_Click;
            // 
            // PreviewsPage
            // 
            PreviewsPage.Location = new Point(13, 16);
            PreviewsPage.Name = "PreviewsPage";
            PreviewsPage.Size = new Size(40, 23);
            PreviewsPage.TabIndex = 0;
            PreviewsPage.Text = "<";
            PreviewsPage.UseVisualStyleBackColor = true;
            PreviewsPage.Click += PreviewsPage_Click;
            // 
            // MainPanel
            // 
            MainPanel.Controls.Add(UserGrid);
            MainPanel.Controls.Add(panel1);
            MainPanel.Dock = DockStyle.Fill;
            MainPanel.Location = new Point(0, 55);
            MainPanel.Name = "MainPanel";
            MainPanel.Size = new Size(826, 572);
            MainPanel.TabIndex = 9;
            // 
            // UserGrid
            // 
            UserGrid.AllowUserToAddRows = false;
            UserGrid.AllowUserToDeleteRows = false;
            UserGrid.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(245, 245, 245);
            UserGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            UserGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            UserGrid.BackgroundColor = Color.Pink;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(240, 240, 240);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = Color.PaleVioletRed;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            UserGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            UserGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.PaleVioletRed;
            dataGridViewCellStyle3.SelectionForeColor = Color.White;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            UserGrid.DefaultCellStyle = dataGridViewCellStyle3;
            UserGrid.Dock = DockStyle.Fill;
            UserGrid.GridColor = Color.RosyBrown;
            UserGrid.ImeMode = ImeMode.NoControl;
            UserGrid.Location = new Point(0, 0);
            UserGrid.MultiSelect = false;
            UserGrid.Name = "UserGrid";
            UserGrid.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = SystemColors.Control;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = Color.PaleVioletRed;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            UserGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            UserGrid.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            UserGrid.RowTemplate.Height = 40;
            UserGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            UserGrid.ShowCellErrors = false;
            UserGrid.ShowCellToolTips = false;
            UserGrid.ShowEditingIcon = false;
            UserGrid.Size = new Size(826, 517);
            UserGrid.TabIndex = 1;
            UserGrid.CellContentClick += ProductGrid_CellContentClick;
            // 
            // AddUsername
            // 
            AddUsername.Location = new Point(9, 87);
            AddUsername.Name = "AddUsername";
            AddUsername.Size = new Size(217, 23);
            AddUsername.TabIndex = 0;
            // 
            // AddLastName
            // 
            AddLastName.Location = new Point(11, 206);
            AddLastName.Name = "AddLastName";
            AddLastName.Size = new Size(217, 23);
            AddLastName.TabIndex = 9;
            // 
            // Price
            // 
            Price.AutoSize = true;
            Price.Location = new Point(11, 183);
            Price.Name = "Price";
            Price.Size = new Size(63, 15);
            Price.TabIndex = 10;
            Price.Text = "Last Name";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(11, 240);
            label11.Name = "label11";
            label11.Size = new Size(30, 15);
            label11.TabIndex = 12;
            label11.Text = "Role";
            // 
            // AddSelectRole
            // 
            AddSelectRole.AutoCompleteCustomSource.AddRange(new string[] { "Admin", "Manager", "Staff" });
            AddSelectRole.DropDownStyle = ComboBoxStyle.DropDownList;
            AddSelectRole.FormattingEnabled = true;
            AddSelectRole.Items.AddRange(new object[] { "Admin", "Manager", "Staff" });
            AddSelectRole.Location = new Point(11, 263);
            AddSelectRole.Name = "AddSelectRole";
            AddSelectRole.Size = new Size(215, 23);
            AddSelectRole.TabIndex = 18;
            // 
            // AddUserPanel
            // 
            AddUserPanel.BorderStyle = BorderStyle.FixedSingle;
            AddUserPanel.Controls.Add(AddSelectRole);
            AddUserPanel.Controls.Add(label11);
            AddUserPanel.Controls.Add(Price);
            AddUserPanel.Controls.Add(AddLastName);
            AddUserPanel.Controls.Add(label9);
            AddUserPanel.Controls.Add(AddFirstName);
            AddUserPanel.Controls.Add(label7);
            AddUserPanel.Controls.Add(panel5);
            AddUserPanel.Controls.Add(AddBtn);
            AddUserPanel.Controls.Add(AddUsername);
            AddUserPanel.Dock = DockStyle.Right;
            AddUserPanel.Location = new Point(826, 55);
            AddUserPanel.Name = "AddUserPanel";
            AddUserPanel.Size = new Size(235, 572);
            AddUserPanel.TabIndex = 8;
            AddUserPanel.Visible = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(11, 118);
            label9.Name = "label9";
            label9.Size = new Size(64, 15);
            label9.TabIndex = 8;
            label9.Text = "First Name";
            // 
            // AddFirstName
            // 
            AddFirstName.Location = new Point(11, 141);
            AddFirstName.Name = "AddFirstName";
            AddFirstName.Size = new Size(217, 23);
            AddFirstName.TabIndex = 7;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(9, 64);
            label7.Name = "label7";
            label7.Size = new Size(60, 15);
            label7.TabIndex = 2;
            label7.Text = "Username";
            // 
            // panel5
            // 
            panel5.BackColor = Color.LightPink;
            panel5.Controls.Add(CloseAddPanelbtn);
            panel5.Controls.Add(label8);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(233, 55);
            panel5.TabIndex = 3;
            // 
            // CloseAddPanelbtn
            // 
            CloseAddPanelbtn.BackColor = Color.Transparent;
            CloseAddPanelbtn.Dock = DockStyle.Right;
            CloseAddPanelbtn.FlatAppearance.BorderSize = 0;
            CloseAddPanelbtn.FlatStyle = FlatStyle.Flat;
            CloseAddPanelbtn.Location = new Point(209, 0);
            CloseAddPanelbtn.Name = "CloseAddPanelbtn";
            CloseAddPanelbtn.Size = new Size(24, 55);
            CloseAddPanelbtn.TabIndex = 7;
            CloseAddPanelbtn.Text = "x";
            CloseAddPanelbtn.UseVisualStyleBackColor = false;
            CloseAddPanelbtn.Click += CloseAddPanelbtn_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(76, 21);
            label8.Name = "label8";
            label8.Size = new Size(55, 15);
            label8.TabIndex = 1;
            label8.Text = "Add User";
            // 
            // AddBtn
            // 
            AddBtn.Location = new Point(76, 313);
            AddBtn.Name = "AddBtn";
            AddBtn.Size = new Size(75, 23);
            AddBtn.TabIndex = 2;
            AddBtn.Text = "Add";
            AddBtn.UseVisualStyleBackColor = true;
            AddBtn.Click += AddBtn_Click_2;
            // 
            // usermanagement
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1296, 627);
            Controls.Add(MainPanel);
            Controls.Add(AddUserPanel);
            Controls.Add(EditUserPanel);
            Controls.Add(NavigationBar);
            Name = "usermanagement";
            Text = "usermanagement";
            EditUserPanel.ResumeLayout(false);
            EditUserPanel.PerformLayout();
            ffsfsdf.ResumeLayout(false);
            ffsfsdf.PerformLayout();
            NavigationBar.ResumeLayout(false);
            NavigationBar.PerformLayout();
            panel1.ResumeLayout(false);
            MainPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)UserGrid).EndInit();
            AddUserPanel.ResumeLayout(false);
            AddUserPanel.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private ComboBox EditProductCategory;
        private ComboBox EditProductSupplier;
        private Label label12;
        private Label label13;
        private TextBox EditProductPrice;
        private Label label10;
        private TextBox EditProductQuantity;
        private TextBox EditProductName;
        private TextBox EditUserName;
        private Label label5;
        private TextBox EditFirstName;
        private Label label4;
        private TextBox EditLastName;
        private Label label3;
        private Label label2;
        private ComboBox EditSelectRole;
        private Panel EditUserPanel;
        private Panel ffsfsdf;
        private Button CloseEditPanelbtn;
        private Label label1;
        private Button UpdateBtn;
        private Panel NavigationBar;
        private Button SearchBtn;
        private TextBox SearchBox;
        private Button OpenAddPanel;
        private Panel panel1;
        private Button NextPage;
        private Button PreviewsPage;
        private Panel MainPanel;
        private DataGridView UserGrid;
        private TextBox AddUsername;
        private TextBox AddLastName;
        private Label Price;
        private Label label11;
        private ComboBox AddSelectRole;
        private Panel AddUserPanel;
        private Label label9;
        private TextBox AddFirstName;
        private Label label7;
        private Panel panel5;
        private Button CloseAddPanelbtn;
        private Label label8;
        private Button AddBtn;
    }
}
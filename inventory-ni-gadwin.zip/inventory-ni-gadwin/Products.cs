﻿using System;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

using System.Windows.Forms;

namespace inventory_ni_gadwin
{
    public partial class products : Form
    {
        public products()
        {
            InitializeComponent();
            LoadData();
            AddActionButtons();
            ProductGrid.Columns["ProductID"].HeaderText = "ID";
            ProductGrid.Columns["StockQuantity"].HeaderText = "Quantity";
            LoadSupplier();

        }

        private int currentPage = 0;
        private int pageSize = 20; // Number of rows per page
        private int totalRows = 0; // Total number of rows (to be calculated)

        private void LoadData()
        {
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Query to count total rows
                    string countQuery = "SELECT COUNT(*) FROM products";
                    MySqlCommand countCmd = new MySqlCommand(countQuery, conn);
                    totalRows = Convert.ToInt32(countCmd.ExecuteScalar());

                    // Calculate total pages
                    int totalPages = (int)Math.Ceiling((double)totalRows / pageSize);

                    // Ensure currentPage stays within bounds
                    if (currentPage < 0)
                        currentPage = 0;
                    else if (currentPage >= totalPages)
                        currentPage = totalPages - 1;

                    // Query for paginated product data
                    string query = $@"
                SELECT 
                    products.ProductID,
                    products.Name,
                    suppliers.Name AS Supplier, -- Get Supplier name instead of SupplierID
                    products.Price,
                    products.StockQuantity,
                    products.Category
                FROM 
                    products
                LEFT JOIN 
                    suppliers ON products.SupplierID = suppliers.SupplierID
                LIMIT {pageSize} OFFSET {currentPage * pageSize}";

                    MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    ProductGrid.DataSource = dataTable;

                    // Optional: Change the header text for the Supplier column
                    if (ProductGrid.Columns.Contains("Supplier"))
                    {
                        ProductGrid.Columns["Supplier"].HeaderText = "Supplier";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }



        private void AddActionButtons()
        {
            // Edit button
            DataGridViewButtonColumn editButton = new DataGridViewButtonColumn
            {
                Name = "Edit",
                HeaderText = "Edit",
                Text = "Edit",
                UseColumnTextForButtonValue = true
            };
            ProductGrid.Columns.Add(editButton);

            // Delete button
            DataGridViewButtonColumn deleteButton = new DataGridViewButtonColumn
            {
                Name = "Delete",
                HeaderText = "Delete",
                Text = "Delete",
                UseColumnTextForButtonValue = true

            };
            ProductGrid.Columns.Add(deleteButton);
        }


        private void addBtn_Click(object sender, EventArgs e)
        {
            AddProductPanel.Visible = true;
            EditProductPanel.Visible = false;
        }


        private void CloseAddPanelbtn_Click(object sender, EventArgs e)
        {
            AddProductPanel.Visible = false;
        }

        private void CloseEditPanelbtn_Click(object sender, EventArgs e)
        {
            EditProductPanel.Visible = false;
        }
        public int selectedproductid;
        private void ProductGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int productId = Convert.ToInt32(ProductGrid.Rows[e.RowIndex].Cells["ProductID"].Value);
            selectedproductid = productId;

            if (e.RowIndex >= 0) // Ensure it's not a header row
            {
                var cellValue = ProductGrid.Rows[e.RowIndex].Cells["ProductID"].Value;

                if (cellValue == null)
                {
                    MessageBox.Show("ProductID is null. Please check the data source or column name.");
                    return;
                }

                string id = cellValue.ToString();

                if (ProductGrid.Columns[e.ColumnIndex].Name == "Edit")
                {

                    LoadProductDetails(productId);
                    AddProductPanel.Visible = false;
                    EditProductPanel.Visible = true;
                }
                else if (ProductGrid.Columns[e.ColumnIndex].Name == "Delete")
                {
                    DeleteRow(id);
                }
            }
        }

        private void DeleteRow(string id)
        {
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Delete query
                    string query = $"DELETE FROM products WHERE ProductID = @id";

                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }
                }

                // Refresh data
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }



        private void NextPage_Click(object sender, EventArgs e)
        {
            if ((currentPage + 1) * pageSize < totalRows)
            {
                currentPage++;
                LoadData();
            }
            else
            {
                MessageBox.Show("You are on the last page.");
            }
        }

        private void PreviewsPage_Click(object sender, EventArgs e)
        {
            if (currentPage > 0)
            {
                currentPage--;
                LoadData();
            }
            else
            {
                MessageBox.Show("You are on the first page.");
            }
        }

        private void LoadSupplier()
        {
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                // Populate Supplier ComboBox
                string supplierQuery = "SELECT Name FROM suppliers";
                using (MySqlCommand cmd = new MySqlCommand(supplierQuery, conn))
                {
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            SelectProductSupplier.Items.Add(reader["Name"].ToString());
                            EditProductSupplier.Items.Add(reader["Name"].ToString());
                        }
                    }
                }


                // Populate Category ComboBox
                string categoryQuery = "SELECT DISTINCT Category FROM products";
                using (MySqlCommand cmd = new MySqlCommand(categoryQuery, conn))
                {
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            EditProductCategory.Items.Add(reader["Category"].ToString());
                            SelectProductCategory.Items.Add(reader["Category"].ToString());
                        }
                    }
                }
            }
        }

        private void AddBtn_Click_1(object sender, EventArgs e)
        {
            string productName = AddProductName.Text;
            string productQuantity = AddProductQuantity.Text;
            string productPrice = AddProductPrice.Text;
            string productCategory = SelectProductCategory.SelectedItem?.ToString();
            string supplierName = SelectProductSupplier.SelectedItem?.ToString();

            //if (string.IsNullOrWhiteSpace(productName) || string.IsNullOrWhiteSpace(productQuantity) ||
            //    string.IsNullOrWhiteSpace(productPrice) || productCategory == null || supplierName == null)
            //{
            //    MessageBox.Show("Please fill in all fields and select both category and supplier.");
            //    return;
            //}

            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();

                // Get Supplier ID
                string supplierQuery = "SELECT SupplierID FROM suppliers WHERE Name = @Name";
                int supplierId = -1;
                using (MySqlCommand cmd = new MySqlCommand(supplierQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", supplierName);
                    supplierId = Convert.ToInt32(cmd.ExecuteScalar());
                }

                // Insert Product
                string insertQuery = @"INSERT INTO products (Name, StockQuantity, Price, Category, SupplierID)
                               VALUES (@Name, @Quantity, @Price, @Category, @SupplierID)";
                using (MySqlCommand cmd = new MySqlCommand(insertQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", productName);
                    cmd.Parameters.AddWithValue("@Quantity", int.Parse(productQuantity));
                    cmd.Parameters.AddWithValue("@Price", decimal.Parse(productPrice));
                    cmd.Parameters.AddWithValue("@Category", productCategory);
                    cmd.Parameters.AddWithValue("@SupplierID", supplierId);

                    cmd.ExecuteNonQuery();
                }

                AddProductName.Text = "";
                AddProductQuantity.Text = "";
                AddProductPrice.Text = "";
                SelectProductCategory.SelectedIndex = -1;
                SelectProductSupplier.SelectedIndex = -1;
                MessageBox.Show("Product added successfully!");
            }
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    // Query to update the product details
                    string query = @"UPDATE Products 
                             SET 
                                Name = @Name,
                                Category = @Category,
                                StockQuantity = @StockQuantity,
                                Price = @Price,
                                SupplierID = (SELECT SupplierID FROM Suppliers WHERE Name = @SupplierName)
                             WHERE ProductID = @ProductID";

                    MySqlCommand cmd = new MySqlCommand(query, conn);

                    // Parameters to update the product
                    cmd.Parameters.AddWithValue("@Name", EditProductName.Text);
                    cmd.Parameters.AddWithValue("@Category", EditProductCategory.Text);
                    cmd.Parameters.AddWithValue("@StockQuantity", Convert.ToInt32(EditProductQuantity.Text));
                    cmd.Parameters.AddWithValue("@Price", Convert.ToDecimal(EditProductPrice.Text));
                    cmd.Parameters.AddWithValue("@SupplierName", EditProductSupplier.Text);
                    cmd.Parameters.AddWithValue("@ProductID", selectedproductid);

                    // Execute the query
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Product details updated successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Failed to update the product.");
                    }

                    // Clear textboxes and combo boxes
                    ClearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }
        private void ClearFields()
        {
            // Clear textboxes
            EditProductName.Clear();
            EditProductQuantity.Clear();
            EditProductPrice.Clear();

            // Clear and reset comboboxes
            EditProductSupplier.Items.Clear();
            EditProductCategory.Items.Clear();
            LoadData();
        }
        private void LoadProductDetails(int productId)
        {
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    // Query to fetch product details
                    string query = @"SELECT 
                                        p.Name AS ProductName,
                                        p.Category AS ProductCategory,
                                        p.StockQuantity,
                                        p.Price,
                                        s.SupplierID,
                                        s.Name AS SupplierName
                                    FROM Products p
                                    JOIN Suppliers s ON p.SupplierID = s.SupplierID
                                    WHERE p.ProductID = @ProductID";

                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@ProductID", productId);

                    MySqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        EditProductName.Text = reader["ProductName"].ToString();
                        EditProductQuantity.Text = reader["StockQuantity"].ToString();
                        EditProductPrice.Text = reader["Price"].ToString();

                        // Populate Supplier ComboBox
                        EditProductSupplier.Items.Clear();
                        EditProductSupplier.Items.Add(reader["SupplierName"].ToString());
                        EditProductSupplier.SelectedIndex = 0;

                        // Populate Category ComboBox
                        EditProductCategory.Items.Clear();
                        EditProductCategory.Items.Add(reader["ProductCategory"].ToString());
                        EditProductCategory.SelectedIndex = 0;
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }
        private void SearchData()
        {
            string connectionString = "Server=localhost;Database=inventory;Uid=root;Pwd=;";
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // SQL query with search filter for the Name column (case-insensitive)
                    string query = $@"
                SELECT 
                    products.ProductID,
                    products.Name,
                    suppliers.Name AS Supplier, -- Get Supplier name instead of SupplierID
                    products.Price,
                    products.StockQuantity,
                    products.Category
                FROM 
                    products
                LEFT JOIN 
                    suppliers ON products.SupplierID = suppliers.SupplierID
                WHERE 
                    LOWER(products.Name) LIKE LOWER(@SearchText)
                LIMIT {pageSize} OFFSET {currentPage * pageSize}";

                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@SearchText", $"%{SearchBox.Text.Trim()}%");

                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    ProductGrid.DataSource = dataTable;

                    // Optional: Change the header text for the Supplier column
                    if (ProductGrid.Columns.Contains("Supplier"))
                    {
                        ProductGrid.Columns["Supplier"].HeaderText = "Supplier";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }


        private void SearchBtn_Click(object sender, EventArgs e)
        {
            SearchData();
        }
    }

}

namespace inventory_ni_gadwin
{
    public partial class Inventory : Form
    {
        public Inventory()
        {
            InitializeComponent();
            LoadForm(new stocktransactions());
            Supplier.Visible = false;
            //btnSettings.Visible = false;
            if (Session.Role == "Staff")
            {
                btnUserMan.Visible = false;
                btnProducts.Visible = false;
            }
            else if (Session.Role == "Manager")
            {
                btnUserMan.Visible = true;
            }
        }
        private void LoadForm(Form form)
        {
                panelMain.Controls.Clear(); // Clear previous form
            form.TopLevel = false;
            form.FormBorderStyle = FormBorderStyle.None;
            form.Dock = DockStyle.Fill;
            panelMain.Controls.Add(form);
            form.Show();
        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            LoadForm(new products());
        }

        private void btnStoTra_Click(object sender, EventArgs e)
        {
            LoadForm(new stocktransactions());
        }

        private void Supplier_Click(object sender, EventArgs e)
        {
            LoadForm(new stocktransactions());
        }


        private void btnUserMan_Click(object sender, EventArgs e)
        {
            LoadForm(new usermanagement());
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            LoadForm(new settings());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SessionManager.Logout();
            this.Close();
        }

        public static class SessionManager
        {
            public static void Logout()
            {
                // Clear the session data
                Session.UserID = 0;
                Session.Username = null;
                Session.Role = null;
                Session.FirstName = null;
                Session.LastName = null;

                // Navigate to Landing.cs
                landing landingPage = new landing();
                landingPage.Show();
                
            }
        }

    }
}

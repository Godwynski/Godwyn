﻿namespace inventory_ni_gadwin
{
    partial class stocktransactions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            SearchBtn = new Button();
            SearchBox = new TextBox();
            OpenSales = new Button();
            NavigationBar = new Panel();
            OpenPurchase = new Button();
            NextPage = new Button();
            PreviewsPage = new Button();
            panel1 = new Panel();
            MainPanel = new Panel();
            panel2 = new Panel();
            TransactionsGrid = new DataGridView();
            PurchasePanel = new Panel();
            PurchaseSelectProduct = new ComboBox();
            label3 = new Label();
            PurchaseQuantity = new TextBox();
            label4 = new Label();
            ffsfsdf = new Panel();
            CloseEditPanelbtn = new Button();
            label1 = new Label();
            UpdateBtn = new Button();
            SalesPanel = new Panel();
            SalesCustomer = new TextBox();
            SalesSelectProduct = new ComboBox();
            dsag = new Panel();
            CloseAddPanelbtn = new Button();
            label8 = new Label();
            AddBtn = new Button();
            label2 = new Label();
            SalesQuantity = new TextBox();
            label7 = new Label();
            label6 = new Label();
            NavigationBar.SuspendLayout();
            panel1.SuspendLayout();
            MainPanel.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)TransactionsGrid).BeginInit();
            PurchasePanel.SuspendLayout();
            ffsfsdf.SuspendLayout();
            SalesPanel.SuspendLayout();
            dsag.SuspendLayout();
            SuspendLayout();
            // 
            // SearchBtn
            // 
            SearchBtn.Dock = DockStyle.Left;
            SearchBtn.Location = new Point(667, 10);
            SearchBtn.Name = "SearchBtn";
            SearchBtn.Size = new Size(75, 35);
            SearchBtn.TabIndex = 3;
            SearchBtn.Text = "Search";
            SearchBtn.UseVisualStyleBackColor = true;
            SearchBtn.Click += SearchBtn_Click;
            // 
            // SearchBox
            // 
            SearchBox.Dock = DockStyle.Left;
            SearchBox.Font = new Font("Segoe UI", 15F);
            SearchBox.Location = new Point(160, 10);
            SearchBox.Margin = new Padding(0);
            SearchBox.Name = "SearchBox";
            SearchBox.Size = new Size(507, 34);
            SearchBox.TabIndex = 2;
            // 
            // OpenSales
            // 
            OpenSales.Dock = DockStyle.Left;
            OpenSales.Location = new Point(85, 10);
            OpenSales.Name = "OpenSales";
            OpenSales.Size = new Size(75, 35);
            OpenSales.TabIndex = 0;
            OpenSales.Text = "Sales";
            OpenSales.UseVisualStyleBackColor = true;
            OpenSales.Click += OpenSales_Click;
            // 
            // NavigationBar
            // 
            NavigationBar.BackColor = Color.Pink;
            NavigationBar.Controls.Add(SearchBtn);
            NavigationBar.Controls.Add(SearchBox);
            NavigationBar.Controls.Add(OpenSales);
            NavigationBar.Controls.Add(OpenPurchase);
            NavigationBar.Dock = DockStyle.Top;
            NavigationBar.Location = new Point(0, 0);
            NavigationBar.Name = "NavigationBar";
            NavigationBar.Padding = new Padding(10);
            NavigationBar.Size = new Size(810, 55);
            NavigationBar.TabIndex = 10;
            // 
            // OpenPurchase
            // 
            OpenPurchase.Dock = DockStyle.Left;
            OpenPurchase.Location = new Point(10, 10);
            OpenPurchase.Name = "OpenPurchase";
            OpenPurchase.Size = new Size(75, 35);
            OpenPurchase.TabIndex = 4;
            OpenPurchase.Text = "Purchase";
            OpenPurchase.UseVisualStyleBackColor = true;
            OpenPurchase.Click += OpenPurchase_Click;
            // 
            // NextPage
            // 
            NextPage.Location = new Point(59, 16);
            NextPage.Name = "NextPage";
            NextPage.Size = new Size(36, 23);
            NextPage.TabIndex = 1;
            NextPage.Text = ">";
            NextPage.UseVisualStyleBackColor = true;
            // 
            // PreviewsPage
            // 
            PreviewsPage.Location = new Point(13, 16);
            PreviewsPage.Name = "PreviewsPage";
            PreviewsPage.Size = new Size(40, 23);
            PreviewsPage.TabIndex = 0;
            PreviewsPage.Text = "<";
            PreviewsPage.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            panel1.Controls.Add(NextPage);
            panel1.Controls.Add(PreviewsPage);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 615);
            panel1.Name = "panel1";
            panel1.Size = new Size(1280, 55);
            panel1.TabIndex = 0;
            // 
            // MainPanel
            // 
            MainPanel.Controls.Add(panel2);
            MainPanel.Controls.Add(NavigationBar);
            MainPanel.Controls.Add(PurchasePanel);
            MainPanel.Controls.Add(SalesPanel);
            MainPanel.Controls.Add(panel1);
            MainPanel.Dock = DockStyle.Fill;
            MainPanel.Location = new Point(0, 0);
            MainPanel.Name = "MainPanel";
            MainPanel.Size = new Size(1280, 670);
            MainPanel.TabIndex = 13;
            // 
            // panel2
            // 
            panel2.Controls.Add(TransactionsGrid);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(0, 55);
            panel2.Name = "panel2";
            panel2.Size = new Size(810, 560);
            panel2.TabIndex = 15;
            // 
            // TransactionsGrid
            // 
            TransactionsGrid.AllowUserToAddRows = false;
            TransactionsGrid.AllowUserToDeleteRows = false;
            TransactionsGrid.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(245, 245, 245);
            TransactionsGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            TransactionsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            TransactionsGrid.BackgroundColor = Color.Pink;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(240, 240, 240);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = Color.PaleVioletRed;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            TransactionsGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            TransactionsGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.PaleVioletRed;
            dataGridViewCellStyle3.SelectionForeColor = Color.White;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            TransactionsGrid.DefaultCellStyle = dataGridViewCellStyle3;
            TransactionsGrid.Dock = DockStyle.Fill;
            TransactionsGrid.GridColor = Color.RosyBrown;
            TransactionsGrid.ImeMode = ImeMode.NoControl;
            TransactionsGrid.Location = new Point(0, 0);
            TransactionsGrid.MultiSelect = false;
            TransactionsGrid.Name = "TransactionsGrid";
            TransactionsGrid.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = SystemColors.Control;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = Color.PaleVioletRed;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            TransactionsGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            TransactionsGrid.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            TransactionsGrid.RowTemplate.Height = 40;
            TransactionsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            TransactionsGrid.ShowCellErrors = false;
            TransactionsGrid.ShowCellToolTips = false;
            TransactionsGrid.ShowEditingIcon = false;
            TransactionsGrid.ShowRowErrors = false;
            TransactionsGrid.Size = new Size(810, 560);
            TransactionsGrid.TabIndex = 2;
            TransactionsGrid.CellContentClick += UserGrid_CellContentClick_1;
            // 
            // PurchasePanel
            // 
            PurchasePanel.BorderStyle = BorderStyle.FixedSingle;
            PurchasePanel.Controls.Add(PurchaseSelectProduct);
            PurchasePanel.Controls.Add(label3);
            PurchasePanel.Controls.Add(PurchaseQuantity);
            PurchasePanel.Controls.Add(label4);
            PurchasePanel.Controls.Add(ffsfsdf);
            PurchasePanel.Controls.Add(UpdateBtn);
            PurchasePanel.Dock = DockStyle.Right;
            PurchasePanel.Location = new Point(810, 0);
            PurchasePanel.Name = "PurchasePanel";
            PurchasePanel.Size = new Size(235, 615);
            PurchasePanel.TabIndex = 13;
            PurchasePanel.Visible = false;
            // 
            // PurchaseSelectProduct
            // 
            PurchaseSelectProduct.AutoCompleteCustomSource.AddRange(new string[] { "Admin", "Manager", "Staff" });
            PurchaseSelectProduct.FormattingEnabled = true;
            PurchaseSelectProduct.Location = new Point(11, 87);
            PurchaseSelectProduct.Name = "PurchaseSelectProduct";
            PurchaseSelectProduct.Size = new Size(215, 23);
            PurchaseSelectProduct.TabIndex = 25;
            PurchaseSelectProduct.SelectedIndexChanged += PurchaseSelectProduct_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(11, 118);
            label3.Name = "label3";
            label3.Size = new Size(53, 15);
            label3.TabIndex = 24;
            label3.Text = "Quantity";
            // 
            // PurchaseQuantity
            // 
            PurchaseQuantity.Location = new Point(10, 141);
            PurchaseQuantity.Name = "PurchaseQuantity";
            PurchaseQuantity.Size = new Size(216, 23);
            PurchaseQuantity.TabIndex = 23;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(11, 64);
            label4.Name = "label4";
            label4.Size = new Size(49, 15);
            label4.TabIndex = 22;
            label4.Text = "Product";
            // 
            // ffsfsdf
            // 
            ffsfsdf.BackColor = Color.LightPink;
            ffsfsdf.Controls.Add(CloseEditPanelbtn);
            ffsfsdf.Controls.Add(label1);
            ffsfsdf.Dock = DockStyle.Top;
            ffsfsdf.Location = new Point(0, 0);
            ffsfsdf.Name = "ffsfsdf";
            ffsfsdf.Size = new Size(233, 55);
            ffsfsdf.TabIndex = 3;
            // 
            // CloseEditPanelbtn
            // 
            CloseEditPanelbtn.BackColor = Color.Transparent;
            CloseEditPanelbtn.Dock = DockStyle.Right;
            CloseEditPanelbtn.FlatAppearance.BorderSize = 0;
            CloseEditPanelbtn.FlatStyle = FlatStyle.Flat;
            CloseEditPanelbtn.Location = new Point(209, 0);
            CloseEditPanelbtn.Name = "CloseEditPanelbtn";
            CloseEditPanelbtn.Size = new Size(24, 55);
            CloseEditPanelbtn.TabIndex = 7;
            CloseEditPanelbtn.Text = "x";
            CloseEditPanelbtn.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(79, 20);
            label1.Name = "label1";
            label1.Size = new Size(91, 15);
            label1.TabIndex = 1;
            label1.Text = "Purchase Order ";
            // 
            // UpdateBtn
            // 
            UpdateBtn.Location = new Point(79, 183);
            UpdateBtn.Name = "UpdateBtn";
            UpdateBtn.Size = new Size(75, 23);
            UpdateBtn.TabIndex = 2;
            UpdateBtn.Text = "Order";
            UpdateBtn.Click += UpdateBtn_Click;
            // 
            // SalesPanel
            // 
            SalesPanel.BorderStyle = BorderStyle.FixedSingle;
            SalesPanel.Controls.Add(SalesCustomer);
            SalesPanel.Controls.Add(SalesSelectProduct);
            SalesPanel.Controls.Add(dsag);
            SalesPanel.Controls.Add(AddBtn);
            SalesPanel.Controls.Add(label2);
            SalesPanel.Controls.Add(SalesQuantity);
            SalesPanel.Controls.Add(label7);
            SalesPanel.Controls.Add(label6);
            SalesPanel.Dock = DockStyle.Right;
            SalesPanel.Location = new Point(1045, 0);
            SalesPanel.Name = "SalesPanel";
            SalesPanel.Size = new Size(235, 615);
            SalesPanel.TabIndex = 14;
            SalesPanel.Visible = false;
            // 
            // SalesCustomer
            // 
            SalesCustomer.Location = new Point(7, 87);
            SalesCustomer.Name = "SalesCustomer";
            SalesCustomer.Size = new Size(216, 23);
            SalesCustomer.TabIndex = 26;
            // 
            // SalesSelectProduct
            // 
            SalesSelectProduct.AutoCompleteCustomSource.AddRange(new string[] { "Admin", "Manager", "Staff" });
            SalesSelectProduct.FormattingEnabled = true;
            SalesSelectProduct.Items.AddRange(new object[] { "Admin", "Manager", "Staff" });
            SalesSelectProduct.Location = new Point(7, 141);
            SalesSelectProduct.Name = "SalesSelectProduct";
            SalesSelectProduct.Size = new Size(215, 23);
            SalesSelectProduct.TabIndex = 31;
            // 
            // dsag
            // 
            dsag.BackColor = Color.LightPink;
            dsag.Controls.Add(CloseAddPanelbtn);
            dsag.Controls.Add(label8);
            dsag.Dock = DockStyle.Top;
            dsag.Location = new Point(0, 0);
            dsag.Name = "dsag";
            dsag.Size = new Size(233, 55);
            dsag.TabIndex = 3;
            // 
            // CloseAddPanelbtn
            // 
            CloseAddPanelbtn.BackColor = Color.Transparent;
            CloseAddPanelbtn.Dock = DockStyle.Right;
            CloseAddPanelbtn.FlatAppearance.BorderSize = 0;
            CloseAddPanelbtn.FlatStyle = FlatStyle.Flat;
            CloseAddPanelbtn.Location = new Point(209, 0);
            CloseAddPanelbtn.Name = "CloseAddPanelbtn";
            CloseAddPanelbtn.Size = new Size(24, 55);
            CloseAddPanelbtn.TabIndex = 7;
            CloseAddPanelbtn.Text = "x";
            CloseAddPanelbtn.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(76, 21);
            label8.Name = "label8";
            label8.Size = new Size(66, 15);
            label8.TabIndex = 1;
            label8.Text = "Sales Order";
            // 
            // AddBtn
            // 
            AddBtn.Location = new Point(76, 262);
            AddBtn.Name = "AddBtn";
            AddBtn.Size = new Size(75, 23);
            AddBtn.TabIndex = 2;
            AddBtn.Text = "Order";
            AddBtn.UseVisualStyleBackColor = true;
            AddBtn.Click += AddBtn_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(7, 183);
            label2.Name = "label2";
            label2.Size = new Size(53, 15);
            label2.TabIndex = 30;
            label2.Text = "Quantity";
            // 
            // SalesQuantity
            // 
            SalesQuantity.Location = new Point(6, 206);
            SalesQuantity.Name = "SalesQuantity";
            SalesQuantity.Size = new Size(216, 23);
            SalesQuantity.TabIndex = 29;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(6, 64);
            label7.Name = "label7";
            label7.Size = new Size(59, 15);
            label7.TabIndex = 27;
            label7.Text = "Customer";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(7, 118);
            label6.Name = "label6";
            label6.Size = new Size(49, 15);
            label6.TabIndex = 28;
            label6.Text = "Product";
            // 
            // stocktransactions
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1280, 670);
            Controls.Add(MainPanel);
            FormBorderStyle = FormBorderStyle.None;
            Name = "stocktransactions";
            Text = "stotra";
            NavigationBar.ResumeLayout(false);
            NavigationBar.PerformLayout();
            panel1.ResumeLayout(false);
            MainPanel.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)TransactionsGrid).EndInit();
            PurchasePanel.ResumeLayout(false);
            PurchasePanel.PerformLayout();
            ffsfsdf.ResumeLayout(false);
            ffsfsdf.PerformLayout();
            SalesPanel.ResumeLayout(false);
            SalesPanel.PerformLayout();
            dsag.ResumeLayout(false);
            dsag.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button SearchBtn;
        private TextBox SearchBox;
        private Button OpenSales;
        private Panel NavigationBar;
        private Button NextPage;
        private Button PreviewsPage;
        private Panel panel1;
        private Panel MainPanel;
        private Panel PurchasePanel;
        private ComboBox PurchaseSelectProduct;
        private Label label3;
        private TextBox PurchaseQuantity;
        private Label label4;
        private Panel ffsfsdf;
        private Button CloseEditPanelbtn;
        private Label label1;
        private Button UpdateBtn;
        private Panel SalesPanel;
        private TextBox SalesCustomer;
        private ComboBox SalesSelectProduct;
        private Panel dsag;
        private Button CloseAddPanelbtn;
        private Label label8;
        private Button AddBtn;
        private Label label2;
        private TextBox SalesQuantity;
        private Label label7;
        private Label label6;
        private Panel panel2;
        private DataGridView TransactionsGrid;
        private Button OpenPurchase;
    }
}